<?php
/**
 * Gets a list of cgSetting objects.
 */
class cgSettingGetListProcessor extends modObjectGetListProcessor {
    public $classKey = 'cgSetting';
    public $languageTopics = array('clientconfig:default');
    public $defaultSortField = 'label';
    public $defaultSortDirection = 'ASC';

    /**
     * Transform the xPDOObject derivative to an array;
     * @param xPDOObject $object
     * @return array
     */
    public function prepareRow(xPDOObject $object) {
        $row = $object->toArray('', false, true);
        return $row;
    }
}
return 'cgSettingGetListProcessor';
